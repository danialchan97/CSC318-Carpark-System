A Pen created at CodePen.io. You can find this one at https://codepen.io/nerdchacha/pen/qNzwaO.

 login and register form with animation